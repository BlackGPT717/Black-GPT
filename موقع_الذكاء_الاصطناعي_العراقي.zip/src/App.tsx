import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";
import { ProfileSetup } from "./components/ProfileSetup";
import { ThemeProvider } from "./components/ThemeProvider";

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-red-900 via-black to-red-800 dark:from-gray-900 dark:via-black dark:to-red-900">
        <Content />
        <Toaster 
          position="top-center"
          toastOptions={{
            style: {
              background: 'rgba(0, 0, 0, 0.8)',
              color: 'white',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              backdropFilter: 'blur(10px)',
            },
          }}
        />
      </div>
    </ThemeProvider>
  );
}

function Content() {
  const user = useQuery(api.users.getCurrentUser);

  if (user === undefined) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="relative">
          <div className="animate-spin rounded-full h-20 w-20 border-4 border-red-500 border-t-transparent"></div>
          <div className="absolute inset-0 animate-pulse rounded-full h-20 w-20 border-4 border-red-300 opacity-30"></div>
          <div className="absolute inset-2 animate-spin rounded-full h-16 w-16 border-2 border-red-400 border-b-transparent" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Unauthenticated>
        <WelcomePage />
      </Unauthenticated>
      
      <Authenticated>
        {user && !user.isProfileComplete ? (
          <ProfileSetup />
        ) : (
          <Dashboard />
        )}
      </Authenticated>
    </>
  );
}

function WelcomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-transparent to-red-800/20"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
      
      <div className="max-w-6xl mx-auto text-center relative z-10">
        {/* Enhanced Header */}
        <div className="mb-16 animate-fade-in">
          <div className="relative inline-block mb-8">
            <h1 className="text-7xl md:text-9xl font-black gradient-text mb-6 animate-pulse-glow">
              عقل عراقي
            </h1>
            <div className="absolute -inset-4 bg-gradient-to-r from-red-500/20 to-red-600/20 blur-xl rounded-full"></div>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 animate-slide-up">
            الذكاء الاصطناعي العراقي الأول
          </h2>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-4 animate-slide-up max-w-3xl mx-auto leading-relaxed">
            منصة متطورة تجمع بين قوة الذكاء الاصطناعي والثقافة العراقية الأصيلة
          </p>
          
          <div className="flex justify-center items-center gap-4 text-lg text-gray-400 animate-slide-up">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              متاح الآن
            </span>
            <span>•</span>
            <span>مجاني بالكامل</span>
            <span>•</span>
            <span>باللغة العربية</span>
          </div>
        </div>

        {/* Enhanced Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <FeatureCard 
            icon="🤖"
            title="مساعد ذكي عراقي"
            description="يفهم اللهجة العراقية ويتفاعل معك بطريقة طبيعية وودودة"
            gradient="from-blue-500 to-blue-600"
            delay="0s"
          />
          <FeatureCard 
            icon="💻"
            title="مساعد البرمجة المتقدم"
            description="يساعدك في تعلم البرمجة وحل المشاكل التقنية بأسلوب مبسط"
            gradient="from-green-500 to-green-600"
            delay="0.2s"
          />
          <FeatureCard 
            icon="📊"
            title="تحليلات ذكية شاملة"
            description="يتابع تقدمك ويقدم إحصائيات مفصلة عن استخدامك للمنصة"
            gradient="from-purple-500 to-purple-600"
            delay="0.4s"
          />
        </div>

        {/* Enhanced Sign In Form */}
        <div className="max-w-md mx-auto">
          <div className="glass rounded-2xl p-8 card-hover">
            <h3 className="text-2xl font-bold text-white mb-6">ابدأ رحلتك معنا</h3>
            <SignInForm />
            <div className="mt-6 text-sm text-gray-400 text-center">
              بالتسجيل، أنت توافق على شروط الاستخدام وسياسة الخصوصية
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 animate-slide-up">
          <StatItem number="1000+" label="مستخدم نشط" />
          <StatItem number="50K+" label="محادثة" />
          <StatItem number="99%" label="رضا المستخدمين" />
          <StatItem number="24/7" label="متاح دائماً" />
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ 
  icon, 
  title, 
  description, 
  gradient, 
  delay 
}: { 
  icon: string; 
  title: string; 
  description: string; 
  gradient: string;
  delay: string;
}) {
  return (
    <div 
      className={`glass rounded-2xl p-8 card-hover animate-slide-up relative overflow-hidden group`}
      style={{ animationDelay: delay }}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
      <div className="relative z-10">
        <div className="text-5xl mb-6 animate-float">{icon}</div>
        <h3 className="text-xl font-bold text-white mb-4">{title}</h3>
        <p className="text-gray-300 leading-relaxed">{description}</p>
      </div>
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
    </div>
  );
}

function StatItem({ number, label }: { number: string; label: string }) {
  return (
    <div className="text-center">
      <div className="text-2xl md:text-3xl font-bold gradient-text-gold mb-2">{number}</div>
      <div className="text-gray-400 text-sm">{label}</div>
    </div>
  );
}
