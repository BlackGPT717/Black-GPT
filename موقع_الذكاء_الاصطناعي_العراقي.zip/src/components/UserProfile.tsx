import React, { useState } from 'react';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { toast } from 'sonner';

export function UserProfile() {
  const user = useQuery(api.users.getCurrentUser);
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  
  const updateProfile = useMutation(api.users.updateProfile);
  const generateUploadUrl = useMutation(api.users.generateUploadUrl);

  React.useEffect(() => {
    if (user) {
      setName(user.name || '');
      setBirthDate(user.birthDate || '');
    }
  }, [user]);

  const handleSave = async () => {
    try {
      await updateProfile({
        name,
        birthDate,
      });
      setIsEditing(false);
      toast.success('تم تحديث الملف الشخصي بنجاح!');
    } catch (error) {
      toast.error('حدث خطأ في التحديث');
    }
  };

  if (!user) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-red-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <div className="bg-black/30 backdrop-blur-sm border border-red-500/20 rounded-2xl p-8">
        <div className="text-center mb-8">
          <div className="w-32 h-32 rounded-full bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center text-white text-4xl font-bold mx-auto mb-4">
            {user.name?.charAt(0).toUpperCase() || '👤'}
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">الملف الشخصي</h2>
        </div>

        <div className="space-y-6">
          {/* Email (Read-only) */}
          <div>
            <label className="block text-white font-medium mb-2">البريد الإلكتروني</label>
            <input
              type="email"
              value={user.email}
              disabled
              className="w-full px-4 py-3 bg-black/20 border border-gray-600 rounded-lg text-gray-400"
            />
          </div>

          {/* Name */}
          <div>
            <label className="block text-white font-medium mb-2">الاسم الكامل</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={!isEditing}
              className={`w-full px-4 py-3 rounded-lg transition-colors ${
                isEditing
                  ? 'bg-black/30 border border-red-500/30 text-white focus:border-red-500 focus:outline-none'
                  : 'bg-black/20 border border-gray-600 text-gray-300'
              }`}
            />
          </div>

          {/* Birth Date */}
          <div>
            <label className="block text-white font-medium mb-2">تاريخ الميلاد</label>
            <input
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              disabled={!isEditing}
              className={`w-full px-4 py-3 rounded-lg transition-colors ${
                isEditing
                  ? 'bg-black/30 border border-red-500/30 text-white focus:border-red-500 focus:outline-none'
                  : 'bg-black/20 border border-gray-600 text-gray-300'
              }`}
            />
          </div>

          {/* Theme */}
          <div>
            <label className="block text-white font-medium mb-2">المظهر الحالي</label>
            <div className="text-gray-300">
              {user.theme === 'dark' ? 'المظهر الداكن 🌙' : 'المظهر الفاتح ☀️'}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-4 pt-4">
            {isEditing ? (
              <>
                <button
                  onClick={handleSave}
                  className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition-colors"
                >
                  حفظ التغييرات
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition-colors"
                >
                  إلغاء
                </button>
              </>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                تعديل الملف الشخصي
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
