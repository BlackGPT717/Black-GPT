import React from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

export function Analytics() {
  const analytics = useQuery(api.analytics.getUserAnalytics);
  const user = useQuery(api.users.getCurrentUser);

  if (!analytics || !user) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-red-500 border-t-transparent"></div>
      </div>
    );
  }

  // تجميع الإحصائيات
  const actionCounts = analytics.reduce((acc, item) => {
    acc[item.action] = (acc[item.action] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalActions = analytics.length;
  const joinDate = new Date(user._creationTime).toLocaleDateString('ar');

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">إحصائياتك الشخصية</h2>
        <p className="text-gray-300">تابع نشاطك وتقدمك في المنصة</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {/* إجمالي الأنشطة */}
        <StatCard
          title="إجمالي الأنشطة"
          value={totalActions.toString()}
          icon="📊"
          color="from-blue-500 to-blue-600"
        />

        {/* تاريخ الانضمام */}
        <StatCard
          title="عضو منذ"
          value={joinDate}
          icon="📅"
          color="from-green-500 to-green-600"
        />

        {/* الجلسات النشطة */}
        <StatCard
          title="تبديل الصفحات"
          value={((actionCounts['tab_switch_chat'] || 0) + (actionCounts['tab_switch_programming'] || 0) + (actionCounts['tab_switch_profile'] || 0) + (actionCounts['tab_switch_analytics'] || 0)).toString()}
          icon="🔄"
          color="from-purple-500 to-purple-600"
        />
      </div>

      {/* تفاصيل الأنشطة */}
      <div className="bg-black/30 backdrop-blur-sm border border-red-500/20 rounded-2xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">تفاصيل الأنشطة</h3>
        
        {Object.keys(actionCounts).length > 0 ? (
          <div className="space-y-3">
            {Object.entries(actionCounts).map(([action, count]) => (
              <div key={action} className="flex justify-between items-center p-3 bg-black/20 rounded-lg">
                <span className="text-white capitalize">
                  {getActionLabel(action)}
                </span>
                <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  {count}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-4xl mb-4">📈</div>
            <p className="text-gray-300">لا توجد أنشطة بعد</p>
            <p className="text-gray-400 text-sm">ابدأ باستخدام المنصة لرؤية إحصائياتك</p>
          </div>
        )}
      </div>

      {/* آخر الأنشطة */}
      <div className="mt-8 bg-black/30 backdrop-blur-sm border border-red-500/20 rounded-2xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">آخر الأنشطة</h3>
        
        {analytics.slice(0, 10).map((item, index) => (
          <div key={index} className="flex justify-between items-center p-3 border-b border-gray-700 last:border-b-0">
            <span className="text-white">{getActionLabel(item.action)}</span>
            <span className="text-gray-400 text-sm">
              {new Date(item.timestamp).toLocaleString('ar')}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, color }: {
  title: string;
  value: string;
  icon: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-r ${color} p-6 rounded-xl text-white`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm opacity-90">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
        <div className="text-3xl opacity-80">{icon}</div>
      </div>
    </div>
  );
}

function getActionLabel(action: string): string {
  const labels: Record<string, string> = {
    'tab_switch_chat': 'دردشة عراقية',
    'tab_switch_programming': 'مساعد البرمجة',
    'tab_switch_profile': 'الملف الشخصي',
    'tab_switch_analytics': 'الإحصائيات',
  };
  
  return labels[action] || action;
}
