import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { Id } from '../../convex/_generated/dataModel';

interface ChatInterfaceProps {
  type: 'iraqi_chat' | 'programming';
}

export function ChatInterface({ type }: ChatInterfaceProps) {
  const [currentSessionId, setCurrentSessionId] = useState<Id<"chatSessions"> | null>(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const sessions = useQuery(api.chat.getChatSessions);
  const messages = useQuery(api.chat.getMessages, 
    currentSessionId ? { sessionId: currentSessionId } : "skip"
  );
  
  const createSession = useMutation(api.chat.createChatSession);
  const sendMessage = useMutation(api.chat.sendMessage);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleCreateSession = async () => {
    const title = type === 'iraqi_chat' 
      ? `دردشة عراقية - ${new Date().toLocaleDateString('ar')}`
      : `جلسة برمجة - ${new Date().toLocaleDateString('ar')}`;
    
    const sessionId = await createSession({ title, type });
    setCurrentSessionId(sessionId);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !currentSessionId || isLoading) return;

    setIsLoading(true);
    try {
      await sendMessage({
        sessionId: currentSessionId,
        content: message.trim(),
      });
      setMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getWelcomeMessage = () => {
    if (type === 'iraqi_chat') {
      return {
        title: 'مرحبًا بيك في الدردشة العراقية! 🇮🇶',
        subtitle: 'احچي معاي بأي شي تريده، راح أرد عليك باللهجة العراقية الأصيلة',
        placeholder: 'اكتب رسالتك هنا...',
        icon: '💬',
        gradient: 'from-blue-500 to-blue-600'
      };
    } else {
      return {
        title: 'مساعد البرمجة العراقي 💻',
        subtitle: 'اسأل أي سؤال عن البرمجة وراح أساعدك بأفضل طريقة',
        placeholder: 'اسأل عن البرمجة...',
        icon: '💻',
        gradient: 'from-green-500 to-green-600'
      };
    }
  };

  const welcome = getWelcomeMessage();

  return (
    <div className="flex h-full">
      {/* Enhanced Sessions Sidebar */}
      <div className="w-80 glass border-r border-red-500/30 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 to-transparent"></div>
        <div className="p-6 relative z-10">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-lg font-bold text-white">الجلسات</h3>
              <p className="text-sm text-gray-400">جلسات {type === 'iraqi_chat' ? 'الدردشة' : 'البرمجة'}</p>
            </div>
            <button
              onClick={handleCreateSession}
              className="btn-glow bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 flex items-center gap-2"
            >
              <span>+</span>
              جديدة
            </button>
          </div>
          
          <div className="space-y-3 max-h-[calc(100vh-12rem)] overflow-y-auto">
            {sessions?.filter(s => s.type === type).map((session) => (
              <button
                key={session._id}
                onClick={() => setCurrentSessionId(session._id)}
                className={`w-full text-right p-4 rounded-xl transition-all duration-300 group relative overflow-hidden ${
                  currentSessionId === session._id
                    ? 'bg-gradient-to-r from-red-500/20 to-red-600/20 border border-red-500/40 shadow-lg'
                    : 'glass-light hover:bg-white/10'
                }`}
              >
                <div className="relative z-10">
                  <div className="text-white font-medium truncate mb-1">{session.title}</div>
                  <div className="text-gray-400 text-xs flex items-center justify-between">
                    <span>{new Date(session._creationTime).toLocaleDateString('ar')}</span>
                    <span className="text-xl">{welcome.icon}</span>
                  </div>
                </div>
                {currentSessionId === session._id && (
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-red-500 to-red-600 rounded-l-full"></div>
                )}
              </button>
            ))}
            
            {sessions?.filter(s => s.type === type).length === 0 && (
              <div className="text-center py-8">
                <div className="text-4xl mb-4 opacity-50">{welcome.icon}</div>
                <p className="text-gray-400 text-sm">لا توجد جلسات بعد</p>
                <p className="text-gray-500 text-xs">ابدأ جلسة جديدة للمحادثة</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Enhanced Chat Area */}
      <div className="flex-1 flex flex-col">
        {!currentSessionId ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center max-w-lg">
              <div className="relative mb-8">
                <div className={`text-8xl mb-6 animate-float`}>
                  {welcome.icon}
                </div>
                <div className={`absolute inset-0 bg-gradient-to-r ${welcome.gradient} opacity-20 blur-3xl rounded-full`}></div>
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-4">{welcome.title}</h2>
              <p className="text-gray-300 mb-8 leading-relaxed text-lg">{welcome.subtitle}</p>
              
              <button
                onClick={handleCreateSession}
                className="btn-glow bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 shadow-lg"
              >
                ابدأ المحادثة الآن
              </button>
              
              <div className="mt-8 grid grid-cols-2 gap-4 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  متاح 24/7
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
                  ردود فورية
                </div>
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Enhanced Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages?.map((msg, index) => (
                <div
                  key={msg._id}
                  className={`flex ${msg.isAI ? 'justify-start' : 'justify-end'} message-bubble`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className={`max-w-xs lg:max-w-md relative group`}>
                    <div
                      className={`px-6 py-4 rounded-2xl shadow-lg transition-all duration-300 ${
                        msg.isAI
                          ? 'bg-gradient-to-r from-gray-800 to-gray-700 text-white border border-red-500/30'
                          : 'bg-gradient-to-r from-red-500 to-red-600 text-white'
                      }`}
                    >
                      <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>
                      <div className="text-xs opacity-70 mt-2 flex items-center justify-between">
                        <span>{new Date(msg.timestamp).toLocaleTimeString('ar')}</span>
                        {msg.isAI && <span className="text-xs">🤖</span>}
                      </div>
                    </div>
                    
                    {/* Message tail */}
                    <div className={`absolute top-4 w-3 h-3 transform rotate-45 ${
                      msg.isAI 
                        ? 'bg-gray-800 -left-1' 
                        : 'bg-red-500 -right-1'
                    }`}></div>
                  </div>
                </div>
              ))}
              
              {/* Typing Indicator */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gradient-to-r from-gray-800 to-gray-700 px-6 py-4 rounded-2xl border border-red-500/30">
                    <div className="typing-indicator">
                      <div className="typing-dot"></div>
                      <div className="typing-dot"></div>
                      <div className="typing-dot"></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Enhanced Message Input */}
            <form onSubmit={handleSendMessage} className="p-6 border-t border-red-500/30 glass">
              <div className="flex gap-4">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={welcome.placeholder}
                  className="flex-1 px-6 py-4 glass rounded-xl text-white placeholder-gray-400 focus:border-red-500 focus:outline-none input-glow transition-all duration-300"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !message.trim()}
                  className="btn-glow bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-4 rounded-xl font-bold transition-all duration-300 flex items-center gap-2"
                >
                  {isLoading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  ) : (
                    <>
                      <span>إرسال</span>
                      <span>📤</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
