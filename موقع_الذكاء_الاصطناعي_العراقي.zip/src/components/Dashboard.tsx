import React, { useState } from 'react';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { SignOutButton } from '../SignOutButton';
import { useTheme } from './ThemeProvider';
import { ChatInterface } from './ChatInterface';
import { UserProfile } from './UserProfile';
import { Analytics } from './Analytics';

type ActiveTab = 'chat' | 'programming' | 'profile' | 'analytics';

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const user = useQuery(api.users.getCurrentUser);
  const { theme, toggleTheme } = useTheme();
  const trackAction = useMutation(api.analytics.trackUserAction);

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    trackAction({ action: `tab_switch_${tab}` });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 dark:from-gray-900 dark:via-black dark:to-red-900">
      {/* Enhanced Header */}
      <header className="glass border-b border-red-500/30 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">ع</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold gradient-text">
                    عقل عراقي
                  </h1>
                  <p className="text-xs text-gray-400">الذكاء الاصطناعي العراقي</p>
                </div>
              </div>
              
              <div className="hidden md:flex items-center space-x-4">
                <span className="text-gray-300">|</span>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {user?.name?.charAt(0).toUpperCase() || '👤'}
                  </div>
                  <span className="text-white font-medium">أهلاً {user?.name || 'حبيبي'}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleTheme}
                className="p-3 rounded-xl glass hover:bg-white/10 transition-all duration-300 group"
                title={theme === 'dark' ? 'تفعيل المظهر الفاتح' : 'تفعيل المظهر الداكن'}
              >
                <span className="text-xl group-hover:scale-110 transition-transform duration-300">
                  {theme === 'dark' ? '🌞' : '🌙'}
                </span>
              </button>
              <SignOutButton />
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-5rem)]">
        {/* Enhanced Sidebar */}
        <aside className="w-72 glass border-r border-red-500/30 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-red-500/5 to-transparent"></div>
          <nav className="p-6 space-y-3 relative z-10">
            <div className="mb-8">
              <h2 className="text-lg font-bold text-white mb-2">القائمة الرئيسية</h2>
              <div className="w-12 h-1 bg-gradient-to-r from-red-500 to-red-600 rounded-full"></div>
            </div>
            
            <NavButton
              active={activeTab === 'chat'}
              onClick={() => handleTabChange('chat')}
              icon="💬"
              label="دردشة عراقية"
              description="تحدث باللهجة العراقية"
            />
            <NavButton
              active={activeTab === 'programming'}
              onClick={() => handleTabChange('programming')}
              icon="💻"
              label="مساعد البرمجة"
              description="تعلم البرمجة بسهولة"
            />
            <NavButton
              active={activeTab === 'profile'}
              onClick={() => handleTabChange('profile')}
              icon="👤"
              label="الملف الشخصي"
              description="إدارة حسابك"
            />
            <NavButton
              active={activeTab === 'analytics'}
              onClick={() => handleTabChange('analytics')}
              icon="📊"
              label="الإحصائيات"
              description="تابع نشاطك"
            />
          </nav>
          
          {/* User Info Card */}
          <div className="absolute bottom-6 left-6 right-6">
            <div className="glass rounded-xl p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center text-white font-bold">
                  {user?.name?.charAt(0).toUpperCase() || '👤'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{user?.name || 'مستخدم'}</p>
                  <p className="text-gray-400 text-sm truncate">{user?.email}</p>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Enhanced Main Content */}
        <main className="flex-1 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-red-500/5 to-transparent"></div>
          <div className="relative z-10 h-full">
            {activeTab === 'chat' && <ChatInterface type="iraqi_chat" />}
            {activeTab === 'programming' && <ChatInterface type="programming" />}
            {activeTab === 'profile' && <UserProfile />}
            {activeTab === 'analytics' && <Analytics />}
          </div>
        </main>
      </div>
    </div>
  );
}

function NavButton({ 
  active, 
  onClick, 
  icon, 
  label,
  description
}: { 
  active: boolean; 
  onClick: () => void; 
  icon: string; 
  label: string;
  description: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center space-x-4 px-4 py-4 rounded-xl transition-all duration-300 group relative overflow-hidden ${
        active
          ? 'bg-gradient-to-r from-red-500/20 to-red-600/20 border border-red-500/40 text-white shadow-lg'
          : 'hover:bg-white/5 text-gray-300 hover:text-white'
      }`}
    >
      <div className={`text-2xl transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>
        {icon}
      </div>
      <div className="flex-1 text-right">
        <div className="font-semibold">{label}</div>
        <div className="text-xs opacity-70">{description}</div>
      </div>
      
      {active && (
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-red-500 to-red-600 rounded-r-full"></div>
      )}
    </button>
  );
}
