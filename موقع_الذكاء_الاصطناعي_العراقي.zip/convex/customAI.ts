"use node";

import { v } from "convex/values";
import { action } from "./_generated/server";

export const callCustomAPI = action({
  args: {
    message: v.string(),
    type: v.union(v.literal("iraqi_chat"), v.literal("programming")),
  },
  handler: async (ctx, args) => {
    try {
      // استبدل هذا الرابط بـ API الخاص بيك
      const API_URL = process.env.CUSTOM_AI_API_URL || "https://your-api-domain.com/api/chat";
      const API_KEY = process.env.CUSTOM_AI_API_KEY;

      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": API_KEY ? `Bearer ${API_KEY}` : "",
        },
        body: JSON.stringify({
          message: args.message,
          type: args.type,
          // أضف أي معاملات أخرى يحتاجها API تبعك
        }),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();
      
      // تأكد من تعديل هذا حسب شكل الرد من API تبعك
      return data.response || data.message || "عذراً، حدث خطأ في الاستجابة";
      
    } catch (error) {
      console.error("Custom API Error:", error);
      
      // رد احتياطي إذا فشل API
      if (args.type === "iraqi_chat") {
        return "عذراً حبيبي، صار مشكلة بالاتصال. جرب مرة ثانية.";
      } else {
        return "عذراً، حدث خطأ في مساعد البرمجة. يرجى المحاولة مرة أخرى.";
      }
    }
  },
});
