import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const trackUserAction = mutation({
  args: {
    action: v.string(),
    metadata: v.optional(v.object({})),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return;

    await ctx.db.insert("userAnalytics", {
      userId,
      action: args.action,
      timestamp: Date.now(),
      metadata: args.metadata,
    });
  },
});

export const getUserAnalytics = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const analytics = await ctx.db
      .query("userAnalytics")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(100);

    return analytics;
  },
});
