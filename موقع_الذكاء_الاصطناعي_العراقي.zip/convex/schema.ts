import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  users: defineTable({
    email: v.string(),
    name: v.optional(v.string()),
    profileImage: v.optional(v.id("_storage")),
    birthDate: v.optional(v.string()),
    theme: v.optional(v.string()), // "light" or "dark"
    isProfileComplete: v.optional(v.boolean()),
    verificationCode: v.optional(v.string()),
    isVerified: v.optional(v.boolean()),
  }).index("by_email", ["email"]),

  chatSessions: defineTable({
    userId: v.id("users"),
    title: v.string(),
    type: v.union(v.literal("iraqi_chat"), v.literal("programming")),
  }).index("by_user", ["userId"]),

  messages: defineTable({
    sessionId: v.id("chatSessions"),
    userId: v.id("users"),
    content: v.string(),
    isAI: v.boolean(),
    timestamp: v.number(),
  }).index("by_session", ["sessionId"]),

  userAnalytics: defineTable({
    userId: v.id("users"),
    action: v.string(),
    timestamp: v.number(),
    metadata: v.optional(v.object({})),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
