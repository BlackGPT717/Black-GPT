import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const createChatSession = mutation({
  args: {
    title: v.string(),
    type: v.union(v.literal("iraqi_chat"), v.literal("programming")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مسموح");

    const sessionId = await ctx.db.insert("chatSessions", {
      userId,
      title: args.title,
      type: args.type,
    });

    return sessionId;
  },
});

export const getChatSessions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const sessions = await ctx.db
      .query("chatSessions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return sessions;
  },
});

export const getMessages = query({
  args: { sessionId: v.id("chatSessions") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const messages = await ctx.db
      .query("messages")
      .withIndex("by_session", (q) => q.eq("sessionId", args.sessionId))
      .order("asc")
      .collect();

    return messages;
  },
});

export const sendMessage = mutation({
  args: {
    sessionId: v.id("chatSessions"),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مسموح");

    // إضافة رسالة المستخدم
    await ctx.db.insert("messages", {
      sessionId: args.sessionId,
      userId,
      content: args.content,
      isAI: false,
      timestamp: Date.now(),
    });

    // جدولة الرد من API المخصص
    await ctx.scheduler.runAfter(0, api.chat.generateAIResponse, {
      sessionId: args.sessionId,
      userMessage: args.content,
    });

    return { success: true };
  },
});

export const generateAIResponse = action({
  args: {
    sessionId: v.id("chatSessions"),
    userMessage: v.string(),
  },
  handler: async (ctx, args) => {
    // الحصول على نوع الجلسة
    const session = await ctx.runQuery(api.chat.getSessionType, {
      sessionId: args.sessionId,
    });

    if (!session) return;

    let aiResponse = "";

    // استخدام API المخصص
    try {
      aiResponse = await ctx.runAction(api.customAI.callCustomAPI, {
        message: args.userMessage,
        type: session.type,
      });
    } catch (error) {
      console.error("AI Response Error:", error);
      aiResponse = "عذراً، حدث خطأ في الاستجابة. يرجى المحاولة مرة أخرى.";
    }

    // إضافة رد الذكاء الاصطناعي
    await ctx.runMutation(api.chat.addAIMessage, {
      sessionId: args.sessionId,
      content: aiResponse,
    });
  },
});

export const getSessionType = query({
  args: { sessionId: v.id("chatSessions") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.sessionId);
  },
});

export const addAIMessage = mutation({
  args: {
    sessionId: v.id("chatSessions"),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("messages", {
      sessionId: args.sessionId,
      userId: "" as any, // AI message
      content: args.content,
      isAI: true,
      timestamp: Date.now(),
    });
  },
});
