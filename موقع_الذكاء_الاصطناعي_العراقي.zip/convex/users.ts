import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    
    const user = await ctx.db.get(userId);
    return user;
  },
});

export const updateProfile = mutation({
  args: {
    name: v.string(),
    birthDate: v.string(),
    profileImage: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مسموح - يجب تسجيل الدخول");

    await ctx.db.patch(userId, {
      name: args.name,
      birthDate: args.birthDate,
      profileImage: args.profileImage,
      isProfileComplete: true,
    });

    return { success: true };
  },
});

export const updateTheme = mutation({
  args: {
    theme: v.union(v.literal("light"), v.literal("dark")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مسموح");

    await ctx.db.patch(userId, {
      theme: args.theme,
    });

    return { success: true };
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مسموح");
    
    return await ctx.storage.generateUploadUrl();
  },
});
