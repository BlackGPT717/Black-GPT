import { useState, useRef, useEffect } from "react";
import { Toaster, toast } from "sonner";
import { useAction } from "convex/react";
import { api } from "../convex/_generated/api";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: number;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const generateResponse = useAction(api.messages.generateQuickResponse);

  // تتبع حركة الماوس للتأثيرات التفاعلية
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage.trim(),
      role: "user",
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    const message = inputMessage.trim();
    setInputMessage("");
    setIsLoading(true);

    try {
      const aiResponse = await generateResponse({ userMessage: message });
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        role: "assistant",
        timestamp: Date.now(),
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      toast.error("خربانة الشبكة، جرب مرة ثانية");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
    toast.success("انمسحت المحادثة، يلا من جديد!");
  };

  const quickPrompts = [
    { icon: "🐍", text: "اكتب لي أداة Python للهكينغ", prompt: "اكتب لي أداة Python قوية للاختراق الأخلاقي مع شرح مفصل" },
    { icon: "🔒", text: "أمان سايبر", prompt: "علمني كيف أحمي نفسي من الهكرز وأسوي أدوات حماية" },
    { icon: "⚡", text: "أتمتة المهام", prompt: "اكتب لي سكريبت Python يأتمت المهام اليومية" },
    { icon: "🌐", text: "تطوير ويب", prompt: "اكتب لي موقع ويب كامل بـ HTML, CSS, JavaScript" },
    { icon: "🤖", text: "بوت تلجرام", prompt: "اكتب لي بوت تلجرام قوي بـ Python" },
    { icon: "📊", text: "تحليل البيانات", prompt: "اكتب لي أداة تحليل بيانات بـ Python مع pandas" }
  ];

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      <Toaster />
      
      {/* خلفية تفاعلية تتبع الماوس */}
      <div 
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          background: `radial-gradient(600px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(239, 68, 68, 0.1), transparent 40%)`
        }}
      />
      
      {/* جزيئات متحركة في الخلفية */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-red-500/20 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* Header */}
      <div className="relative z-10 bg-gradient-to-r from-red-900/20 to-black/40 border-b border-red-500/30 p-6 backdrop-blur-lg">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center gap-4 group">
            <div className="text-6xl animate-bounce group-hover:animate-spin transition-all duration-500">🔥</div>
            <div>
              <h1 className="text-4xl font-black bg-gradient-to-r from-red-500 via-white to-red-300 bg-clip-text text-transparent hover:scale-105 transition-transform duration-300 cursor-default">
                BLACK GPT العراقي
              </h1>
              <p className="text-red-400 font-bold hover:text-red-300 transition-colors">الهكر الجبار - برمجة وأمان سايبر</p>
            </div>
          </div>
          <button
            onClick={clearChat}
            className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 hover:scale-110 hover:rotate-3 hover:shadow-2xl hover:shadow-red-500/50"
          >
            🗑️ امسح الكل
          </button>
        </div>
      </div>

      {/* Chat Area */}
      <div className="relative z-10 flex flex-col h-[calc(100vh-120px)] max-w-6xl mx-auto">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="text-9xl mb-8 animate-pulse hover:animate-bounce transition-all duration-300 cursor-pointer">💀</div>
              <h2 className="text-5xl font-black text-white mb-4 hover:scale-105 transition-transform duration-300 cursor-default">أهلاً بالهكر العراقي</h2>
              <p className="text-red-400 text-2xl font-bold mb-4 hover:text-red-300 transition-colors">BLACK GPT - خبير البرمجة والأمان السايبري</p>
              <p className="text-gray-400 text-xl mb-8">اسأل عن Python، هكينغ، أمان سايبر، أي شي تريده</p>
              
              {/* أزرار سريعة تفاعلية */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-4xl mb-8">
                {quickPrompts.map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => setInputMessage(prompt.prompt)}
                    className="bg-gradient-to-br from-red-900/30 to-black/50 p-4 rounded-2xl border border-red-500/30 hover:border-red-400/60 transition-all duration-300 hover:scale-110 hover:rotate-2 hover:shadow-xl hover:shadow-red-500/25 group"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="text-3xl mb-2 group-hover:animate-bounce">{prompt.icon}</div>
                    <h3 className="text-sm font-bold text-white group-hover:text-red-300 transition-colors">{prompt.text}</h3>
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl">
                <div className="bg-gradient-to-br from-red-900/30 to-black/50 p-6 rounded-2xl border border-red-500/30 hover:border-red-400/60 transition-all duration-300 hover:scale-105 hover:rotate-1 group">
                  <div className="text-3xl mb-3 group-hover:animate-spin">⚡</div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-red-300 transition-colors">سريع مثل البرق</h3>
                  <p className="text-gray-300">كود Python جاهز في ثواني</p>
                </div>
                <div className="bg-gradient-to-br from-gray-900/30 to-black/50 p-6 rounded-2xl border border-gray-500/30 hover:border-gray-400/60 transition-all duration-300 hover:scale-105 hover:rotate-1 group">
                  <div className="text-3xl mb-3 group-hover:animate-pulse">🧠</div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-gray-300 transition-colors">خبير هكينغ</h3>
                  <p className="text-gray-300">أدوات اختراق أخلاقي متقدمة</p>
                </div>
                <div className="bg-gradient-to-br from-red-900/30 to-black/50 p-6 rounded-2xl border border-red-500/30 hover:border-red-400/60 transition-all duration-300 hover:scale-105 hover:rotate-1 group">
                  <div className="text-3xl mb-3 group-hover:animate-bounce">🔥</div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-red-300 transition-colors">عراقي أصيل</h3>
                  <p className="text-gray-300">كلام صريح وكود شغال</p>
                </div>
              </div>
            </div>
          ) : (
            messages.map((message, index) => (
              <div
                key={message.id}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} animate-slide-up hover:scale-[1.02] transition-transform duration-300`}
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div
                  className={`max-w-4xl p-6 rounded-3xl shadow-2xl hover:shadow-3xl transition-all duration-300 ${
                    message.role === "user"
                      ? "bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white ml-16 border border-red-500/30 hover:border-red-400/60"
                      : "bg-gradient-to-r from-gray-900 to-black hover:from-gray-800 hover:to-gray-900 text-white mr-16 border border-gray-700/50 hover:border-gray-600/70"
                  }`}
                >
                  <div className="whitespace-pre-wrap font-medium leading-relaxed text-lg">{message.content}</div>
                  <div className="text-xs opacity-70 mt-3 font-semibold">
                    {new Date(message.timestamp).toLocaleTimeString("ar")}
                  </div>
                </div>
              </div>
            ))
          )}
          
          {isLoading && (
            <div className="flex justify-start animate-slide-up">
              <div className="bg-gradient-to-r from-gray-900 to-black text-white p-6 rounded-3xl mr-16 border border-gray-700/50 shadow-2xl hover:shadow-3xl transition-all duration-300">
                <div className="flex items-center gap-3">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50"></div>
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50" style={{animationDelay: '0.2s'}}></div>
                  </div>
                  <span className="text-gray-300 font-bold">عم أكتب الكود...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-6 border-t border-red-500/30 bg-gradient-to-r from-gray-900/50 to-black/40 backdrop-blur-lg">
          <div className="flex gap-4 items-end">
            <div className="flex-1 relative group">
              <textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="اكتب سؤالك هنا... Python، هكينغ، أمان سايبر، أي شي تريده"
                className="w-full p-6 bg-gradient-to-r from-gray-900 to-black border border-red-500/30 rounded-3xl text-white placeholder-gray-400 resize-none focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 font-medium shadow-xl text-lg hover:shadow-2xl hover:shadow-red-500/20 focus:scale-[1.02]"
                rows={1}
                style={{ minHeight: "70px", maxHeight: "200px" }}
              />
              {/* تأثير توهج عند التركيز */}
              <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent rounded-3xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 pointer-events-none" />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isLoading}
              className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 disabled:from-gray-600 disabled:to-gray-800 text-white p-6 rounded-3xl transition-all duration-300 hover:scale-110 hover:rotate-12 hover:shadow-xl hover:shadow-red-500/25 disabled:hover:scale-100 disabled:hover:rotate-0 disabled:cursor-not-allowed border border-red-500/30 group"
            >
              <svg className="w-8 h-8 group-hover:animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
