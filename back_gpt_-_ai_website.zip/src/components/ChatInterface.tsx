import { useState, useRef, useEffect } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignOutButton } from "../SignOutButton";
import { toast } from "sonner";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: number;
}

interface Conversation {
  _id: string;
  title: string;
  lastMessageAt: number;
}

export function ChatInterface() {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations] = useState<Conversation[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const generateResponse = useAction(api.messages.generateQuickResponse);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleNewChat = async () => {
    setMessages([]);
    setSelectedConversation("new-chat");
    toast.success("محادثة جديدة جاهزة!");
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage.trim(),
      role: "user",
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    const message = inputMessage.trim();
    setInputMessage("");
    setIsLoading(true);

    if (!selectedConversation) {
      setSelectedConversation("new-chat");
    }

    try {
      const aiResponse = await generateResponse({ userMessage: message });
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        role: "assistant",
        timestamp: Date.now(),
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      toast.error("خربانة الشبكة، جرب مرة ثانية");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setSelectedConversation(null);
    toast.success("انمسحت المحادثة، يلا من جديد!");
  };

  return (
    <div className="flex h-screen bg-black">
      {/* Sidebar */}
      <div className="w-80 bg-gradient-to-b from-gray-900 to-black border-r border-red-500/30 flex flex-col shadow-2xl">
        <div className="p-6 border-b border-red-500/30 bg-gradient-to-r from-red-900/20 to-black/40">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-black bg-gradient-to-r from-red-500 to-white bg-clip-text text-transparent drop-shadow-lg">
              BLACK GPT
            </h1>
            <SignOutButton />
          </div>
          <button
            onClick={handleNewChat}
            className="w-full bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold py-4 px-6 rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-500/25 border border-red-500/30"
          >
            🔥 محادثة جديدة
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-3">
            {conversations.map((conv) => (
              <button
                key={conv._id}
                onClick={() => setSelectedConversation(conv._id)}
                className={`w-full text-right p-4 rounded-xl transition-all duration-300 hover:bg-gray-800/50 border ${
                  selectedConversation === conv._id
                    ? "bg-gradient-to-r from-red-900/30 to-gray-900/50 border-red-500/50 shadow-lg shadow-red-500/20"
                    : "bg-gray-900/30 hover:bg-gray-800/50 border-gray-700/30"
                }`}
              >
                <div className="text-white font-bold truncate">{conv.title}</div>
                <div className="text-gray-400 text-sm mt-1">
                  {new Date(conv.lastMessageAt).toLocaleDateString("ar")}
                </div>
              </button>
            ))}
          </div>
        </div>
        
        <div className="p-6 border-t border-red-500/30 bg-gradient-to-r from-gray-900/50 to-black/40">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-700 rounded-full flex items-center justify-center shadow-lg shadow-red-500/30">
              <span className="text-white font-black text-lg">B</span>
            </div>
            <div className="text-white font-semibold">مستخدم BLACK GPT</div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-gradient-to-br from-black via-gray-900 to-black">
        {selectedConversation ? (
          <>
            {/* Header */}
            <div className="p-6 border-b border-red-500/30 bg-gradient-to-r from-gray-900/50 to-black/40 flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">BLACK GPT العراقي</h2>
              <button
                onClick={clearChat}
                className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold py-2 px-4 rounded-xl transition-all duration-300 hover:scale-105"
              >
                🗑️ امسح
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-8 space-y-8">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <div className="text-8xl mb-6 animate-bounce">💀</div>
                  <h2 className="text-4xl font-black text-white mb-4">أهلاً وسهلاً عزيزي</h2>
                  <p className="text-red-400 text-xl font-bold">BLACK GPT العراقي الأصيل</p>
                  <p className="text-gray-400 text-lg mt-2">اسأل أي شي - برمجة، حياة، أي شي تريده</p>
                </div>
              ) : (
                messages.map((message: Message, index: number) => (
                  <div
                    key={message.id}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} animate-slide-up`}
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div
                      className={`max-w-4xl p-6 rounded-3xl shadow-2xl ${
                        message.role === "user"
                          ? "bg-gradient-to-r from-red-600 to-red-800 text-white ml-16 border border-red-500/30"
                          : "bg-gradient-to-r from-gray-900 to-black text-white mr-16 border border-gray-700/50"
                      }`}
                    >
                      <div className="whitespace-pre-wrap font-medium leading-relaxed">{message.content}</div>
                      <div className="text-xs opacity-70 mt-3 font-semibold">
                        {new Date(message.timestamp).toLocaleTimeString("ar")}
                      </div>
                    </div>
                  </div>
                ))
              )}
              
              {isLoading && (
                <div className="flex justify-start animate-slide-up">
                  <div className="bg-gradient-to-r from-gray-900 to-black text-white p-6 rounded-3xl mr-16 border border-gray-700/50 shadow-2xl">
                    <div className="flex items-center gap-3">
                      <div className="flex gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50"></div>
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce shadow-lg shadow-red-500/50" style={{animationDelay: '0.2s'}}></div>
                      </div>
                      <span className="text-gray-300 font-bold">عم أفكر شوية...</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-8 border-t border-red-500/30 bg-gradient-to-r from-gray-900/50 to-black/40">
              <div className="flex gap-6 items-end">
                <div className="flex-1 relative">
                  <textarea
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="اكتب سؤالك هنا... برمجة، مشاكل، أي شي تريده"
                    className="w-full p-6 bg-gradient-to-r from-gray-900 to-black border border-red-500/30 rounded-3xl text-white placeholder-gray-400 resize-none focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 font-medium shadow-xl"
                    rows={1}
                    style={{ minHeight: "64px", maxHeight: "200px" }}
                  />
                </div>
                <button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isLoading}
                  className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 disabled:from-gray-600 disabled:to-gray-800 text-white p-6 rounded-3xl transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-red-500/25 disabled:hover:scale-100 disabled:cursor-not-allowed border border-red-500/30"
                >
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="text-9xl mb-8 animate-pulse">🔥</div>
            <h2 className="text-5xl font-black text-white mb-6">BLACK GPT العراقي</h2>
            <p className="text-2xl text-red-400 mb-4 font-bold">الذكاء الاصطناعي الأسود</p>
            <p className="text-xl text-gray-400 mb-12">ابدأ محادثة جديدة واسأل أي شي تريده</p>
            <button
              onClick={handleNewChat}
              className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-black py-6 px-12 rounded-3xl transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-red-500/25 border border-red-500/30"
            >
              🚀 ابدأ المحادثة الآن
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
