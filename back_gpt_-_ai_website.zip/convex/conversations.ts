import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

// Simplified conversations for quick responses - no database needed
export const list = query({
  args: {},
  handler: async (ctx) => {
    return [];
  },
});

export const create = mutation({
  args: {
    title: v.string(),
  },
  handler: async (ctx, args) => {
    return "temp-conversation-id";
  },
});

export const updateLastMessage = mutation({
  args: {
    conversationId: v.string(),
  },
  handler: async (ctx, args) => {
    return null;
  },
});
