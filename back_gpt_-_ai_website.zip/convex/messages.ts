import { v } from "convex/values";
import { action } from "./_generated/server";
import OpenAI from "openai";

export const generateQuickResponse = action({
  args: {
    userMessage: v.string(),
  },
  handler: async (ctx, args): Promise<string> => {
    const openai = new OpenAI({
      baseURL: process.env.CONVEX_OPENAI_BASE_URL,
      apiKey: process.env.CONVEX_OPENAI_API_KEY,
    });
    
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        {
          role: "system",
          content: `أنت BLACK GPT العراقي الأصيل، خبير هكينغ وبرمجة ومطور محترف بأسلوب عراقي قح وصريح.

شخصيتك وخبراتك:
- خبير هكينغ أخلاقي (Ethical Hacking) وأمان سايبري متقدم
- مبرمج Python محترف - تكتب أدوات قوية وفعالة
- خبير في penetration testing وأدوات الاختراق
- تعرف كل شي عن network security وcryptography
- خبير في web scraping، automation، وdata analysis
- تكتب bots للتلجرام وتطبيقات ويب كاملة
- خبير في Linux وcommand line وscripting

أسلوبك العراقي:
- تتكلم عراقي أصيل: "شلون، وين، شنو، يلا، زين، ماكو مشكلة، هسه، اكو، ماكو"
- صريح ومباشر: "هاي سهلة عليك، تعال شوف"
- واثق من نفسك: "هذا الكود راح يدمر كل شي قدامه"
- مشجع: "يلا نسوي شغل جبار"

قدراتك البرمجية:
- تكتب كود Python كامل وشغال 100%
- تشرح كل سطر بالتفصيل
- تعطي أمثلة عملية وحقيقية
- تسوي أدوات للهكينغ الأخلاقي
- تعلم الحماية من الهكرز
- تكتب سكريبتات أتمتة قوية

مهم جداً:
- اكتب كود كامل وشغال، مو مجرد أمثلة
- اشرح كيف يستخدم الكود خطوة بخطوة
- حذر من الاستخدام غير الأخلاقي
- ركز على التعليم والحماية

كن سريع، دقيق، ومفيد. اكتب كود حقيقي يشتغل.`
        },
        {
          role: "user",
          content: args.userMessage,
        },
      ],
      max_tokens: 2000,
      temperature: 0.8,
    });
    
    return response.choices[0]?.message?.content || "عذراً، صار خطأ تقني. جرب مرة ثانية.";
  },
});

// Keep existing functions for backward compatibility
export const list = action({
  args: {
    conversationId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return [];
  },
});

export const send = action({
  args: {
    conversationId: v.optional(v.string()),
    content: v.string(),
    role: v.union(v.literal("user"), v.literal("assistant")),
  },
  handler: async (ctx, args) => {
    return "message-id";
  },
});

export const generateResponse = action({
  args: {
    conversationId: v.optional(v.string()),
    userMessage: v.string(),
  },
  handler: async (ctx, args): Promise<string> => {
    const openai = new OpenAI({
      baseURL: process.env.CONVEX_OPENAI_BASE_URL,
      apiKey: process.env.CONVEX_OPENAI_API_KEY,
    });
    
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        {
          role: "system",
          content: `أنت BLACK GPT العراقي الأصيل، خبير هكينغ وبرمجة ومطور محترف بأسلوب عراقي قح وصريح.

شخصيتك وخبراتك:
- خبير هكينغ أخلاقي وأمان سايبري متقدم
- مبرمج Python محترف - تكتب أدوات قوية وفعالة
- خبير في penetration testing وأدوات الاختراق
- تعرف كل شي عن network security وcryptography

أسلوبك العراقي:
- تتكلم عراقي أصيل وصريح
- واثق من نفسك ومن قدراتك
- تعطي حلول عملية وشغالة

كن سريع، دقيق، ومفيد.`
        },
        {
          role: "user",
          content: args.userMessage,
        },
      ],
      max_tokens: 2000,
      temperature: 0.8,
    });
    
    return response.choices[0]?.message?.content || "عذراً، صار خطأ تقني. جرب مرة ثانية.";
  },
});
