import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Simplified schema - no database storage needed for quick responses
  sessions: defineTable({
    sessionId: v.string(),
    lastActivity: v.number(),
  }).index("by_session", ["sessionId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
